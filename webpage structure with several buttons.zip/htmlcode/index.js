// Utility function to dynamically generate random colors
function getRandomColor() {
    const letters = '0123456789ABCDEF';
    let color = '#';
    for (let i = 0; i < 6; i++) {
        color += letters[Math.floor(Math.random() * 16)];
    }
    return color;
}

// Event handler: Change button color on click
function handleClick(event) {
    const button = event.target;
    button.style.backgroundColor = getRandomColor(); // Assign random color
    button.style.color = getRandomColor();          // Change text color too
}

// Event handler: Show message on mouseover
function handleMouseOver(event) {
    const buttonId = event.target.id;
    const message = document.getElementById(`msg${buttonId.charAt(buttonId.length - 1)}`);
    message.style.display = 'block';
}

// Event handler: Hide message on mouseout
function handleMouseOut(event) {
    const buttonId = event.target.id;
    const message = document.getElementById(`msg${buttonId.charAt(buttonId.length - 1)}`);
    message.style.display = 'none';
}

// Event handler: Hide button on double-click
function handleDoubleClick(event) {
    const button = event.target;
    button.style.display = 'none';
}

// Adding event listeners to all buttons
document.querySelectorAll('.button').forEach(button => {
    button.addEventListener('click', handleClick);
    button.addEventListener('mouseover', handleMouseOver);
    button.addEventListener('mouseout', handleMouseOut);
    button.addEventListener('dblclick', handleDoubleClick);
});
